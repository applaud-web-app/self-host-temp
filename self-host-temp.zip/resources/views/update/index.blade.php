@extends('layouts.master')

@section('content')
<section class="content-body">
  <div class="container-fluid position-relative">
    {{-- page title --}}
    <div class="d-flex align-items-center mb-4">
      <h2 class="fw-semibold me-auto mb-0">Application Update</h2>
    </div>

    <div class="row">
      <div class="col-lg-12">
        <div class="card h-auto">
          <div class="card-header bg-white border-0 py-3">
            <h5 class="mb-0">
              Current Version:
              <span class="badge bg-secondary">v{{ $currentVersion }}</span>
            </h5>
          </div>

          <div class="card-body">
            <div class="alert alert-warning d-flex align-items-start rounded-3">
              <i class="fas fa-exclamation-triangle fa-lg mt-1 me-2"></i>
              <div>
                <strong class="d-block">Update available</strong>
                A new version is available to install. Upload the update file and proceed with installation.
              </div>
            </div>

            {{-- Upload ZIP Form --}}
            <div class="d-flex flex-wrap align-items-center gap-3">
              <form id="upload-form" enctype="multipart/form-data">
                @csrf
                <input type="file" name="update_zip" class="form-control mb-2" accept=".zip" required>
                <button type="submit" class="btn btn-lg btn-primary px-4" id="install-update">
                  <i class="fas fa-rocket me-2"></i> Upload & Install
                </button>
              </form>
            </div>

            {{-- Progress Section --}}
            <div id="install-progress" class="mt-4" style="display:none;">
              <div class="progress" style="height: .875rem;">
                <div class="progress-bar progress-bar-striped progress-bar-animated rounded-pill" style="width:0%"></div>
              </div>
              <div id="install-status" class="small text-muted mt-2">Starting the update...</div>
            </div>
          </div>

          <div class="card-footer bg-light border-0 small text-muted">
            <i class="fas fa-clock me-1"></i> Last checked:
            {{ now()->format('Y-m-d H:i:s') }}
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
@endsection

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
$(function () {
  $('#upload-form').on('submit', function (e) {
    e.preventDefault();

    Swal.fire({
      title: 'Upload & Install update?',
      text: 'This will replace application files with the uploaded ZIP.',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, install',
      reverseButtons: true,
    }).then(result => {
      if (!result.isConfirmed) return;

      const $btn = $('#install-update')
        .prop('disabled', true)
        .html('<i class="fas fa-spinner fa-spin"></i> Installing…');

      $('#install-progress').slideDown();
      $('#install-status').html('Uploading & installing...');

      const poll = setInterval(() => {
        $.get('{{ route('update.progress') }}', data => {
          $('#install-progress .progress-bar').css('width', data.progress + '%');
          $('#install-status').text(data.message);
        });
      }, 1000);

      const formData = new FormData(this);

      $.ajax({
        url: '{{ route('update.install') }}',
        method: 'POST',
        data: formData,
        processData: false,
        contentType: false,
      })
      .done(res => {
        clearInterval(poll);
        $('#install-progress .progress-bar').css('width', '100%');
        $('#install-status').html('<i class="fas fa-check-circle text-success"></i> ' + res.message);
        Swal.fire('Done', res.message, 'success').then(() => location.reload());
      })
      .fail((xhr, status, error) => {
        clearInterval(poll);
        let msg = 'Installation failed.';
        if (xhr.responseJSON?.message) msg = xhr.responseJSON.message;
        else if (xhr.status === 503) msg = 'Service Unavailable — app may still be in maintenance mode.';
        else if (error) msg = error;

        $('#install-progress .progress-bar').addClass('bg-danger').css('width', '100%');
        $('#install-status').html('<i class="fas fa-times-circle text-danger"></i> ' + msg);
        $btn.prop('disabled', false).html('<i class="fas fa-rocket me-2"></i> Upload & Install');
        Swal.fire('Error', msg, 'error');
      });
    });
  });
});
</script>
@endpush