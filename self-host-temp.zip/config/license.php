<?php

return [
    'LICENSE_CODE' => env('LICENSE_CODE'),
    'APP_DOMAIN' => env('APP_DOMAIN'),
    'LICENSE_USER' => env('LICENSE_USER'),
    'LICENSE_EMAIL' => env('LICENSE_EMAIL'),
];
