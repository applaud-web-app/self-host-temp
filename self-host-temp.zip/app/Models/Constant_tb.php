<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Constant_tb extends Model
{
    //
}
