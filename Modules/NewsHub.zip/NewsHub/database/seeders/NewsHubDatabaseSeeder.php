<?php

namespace Modules\NewsHub\Database\Seeders;

use Illuminate\Database\Seeder;

class NewsHubDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
