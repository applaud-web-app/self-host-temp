<?php

return [
    'name' => 'NewsHub',
];
