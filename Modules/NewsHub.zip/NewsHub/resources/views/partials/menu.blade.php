<li>
    <a class="ai-icon" href="{{ route('news-hub.index') }}" aria-expanded="false">
        <i class="fal fa-newspaper"></i>
        <span class="nav-text">News Hub</span>
    </a>
</li>