<li>
    <a class="ai-icon" href="{{ route('customprompt.index') }}" aria-expanded="false">
        <i class="fal fa-credit-card"></i>
        <span class="nav-text">Custom Prompt</span>
    </a>
</li>