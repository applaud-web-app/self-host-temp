<?php

return [
    'name' => 'CustomPrompt',
];
