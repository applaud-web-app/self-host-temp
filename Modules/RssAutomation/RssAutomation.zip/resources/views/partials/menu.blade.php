@php
    // $isInstalled = \App\Models\Addon::where('name', 'Rss Addon')->where('status', 'installed')->exists();
@endphp

@php
    // ── build “App\Models\Addon” ──
    $cls = implode('', [
        base64_decode('QXBw'),         // "App"
        base64_decode('XE1vZGVscw=='), // "\Models"
        base64_decode('XEFkZG9u'),     // "\Addon"
    ]);

    // ── build method names ──
    $mWhere  = implode('', [ base64_decode('d2hlcmU=') ]); // "where"
    $mExists = implode('', [ base64_decode('ZXhpc3Rz') ]); // "exists"

    // ── build column/value strings ──
    $colName   = implode('', [ base64_decode('bmFtZQ==') ]);      // "name"
    $valName   = implode('', [ base64_decode('UnNzIEFkZG9u') ]);  // "Rss Addon"
    $colStatus = implode('', [ base64_decode('c3RhdHVz') ]);      // "status"
    $valStatus = implode('', [ base64_decode('aW5zdGFsbGVk') ]);  // "installed"

    // ── perform the query ──
    $isInstalled = $cls::{$mWhere}($colName,   $valName)
                       ->{$mWhere}($colStatus, $valStatus)
                       ->{$mExists}();
@endphp

@if($isInstalled)
    <li>
        <a class="has-arrow ai-icon" href="javascript:void(0)" aria-expanded="false">
            <i class="fas fa-rss"></i>
            <span class="nav-text">RSS Automation</span>
        </a>
        <ul aria-expanded="false">
            <li>
                <a href="{{ route('rssautomation.report') }}">
                    <span class="nav-text">RSS Feed Report</span>
                </a>
            </li>
            <li>
                <a href="{{ route('rssautomation.add') }}">
                    <span class="nav-text">Add RSS Feed</span>
                </a>
            </li>
        </ul>
    </li>
@endif
