<?php

namespace Modules\RssAutomation\Database\Seeders;

use Illuminate\Database\Seeder;

class RssAutomationDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
