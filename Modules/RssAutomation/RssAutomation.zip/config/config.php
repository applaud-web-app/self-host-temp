<?php

return [
    'rss_name' => 'RssAutomation',
    'rss_key' => env('RSS_ADDON_KEY', ''),
];