<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}

// Clean up plugin data
global $wpdb;
$table_name = esc_sql($wpdb->prefix . 'aplu_push');
$wpdb->query("DROP TABLE IF EXISTS `{$table_name}`");


delete_option('aplu_push_domain_name');
delete_option('aplu_push_license_key');
delete_option('aplu_push_settings');

$file_path = ABSPATH . 'aplupush-messaging-sw.js';
if (file_exists($file_path)) {
    wp_delete_file($file_path);
}
