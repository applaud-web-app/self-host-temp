<?php
/*
 * Plugin name: Aplu Push
 * Plugin URI: https://www.aplu.io
 * Description: Browser push notifications for your site, available in Chrome, Safari and Firefox.
 * Author: aplu
 * Author URI: https://www.aplu.io
 * Version: 1.0.5
 * License: GPL v2 or later
 * Domain Path: /languages
 * Requires at least: 4.9
 * Tested up to: 6.0
 */

// Ensure WordPress is loaded
defined('ABSPATH') || exit;

// Minimum WordPress version check
function aplu_push_check_wp_version() {
    global $wp_version;
    $required_wp_version = '4.9'; // Set your minimum required version

    if (version_compare($wp_version, $required_wp_version, '<')) {
        deactivate_plugins(plugin_basename(__FILE__)); // Deactivate the plugin
        add_action('admin_notices', 'aplu_push_minimum_wp_version_notice');
    }
}
register_activation_hook(__FILE__, 'aplu_push_check_wp_version');

// Display admin notice if WordPress version is below the minimum requirement
function aplu_push_minimum_wp_version_notice() {
    $class = 'notice notice-error';
    $message = __('Aplu Push requires WordPress version 4.9 or higher. The plugin has been deactivated.', 'aplu-push');

    printf('<div class="%1$s"><p>%2$s</p></div>', esc_attr($class), esc_html($message));
}

// Load necessary files
require_once plugin_dir_path(__FILE__) . 'includes/settings-page.php';
require_once plugin_dir_path(__FILE__) . 'includes/admin-assets.php';
require_once plugin_dir_path(__FILE__) . 'includes/frontend-assets.php';
require_once plugin_dir_path(__FILE__) . 'includes/firebase-file.php';
require_once plugin_dir_path(__FILE__) . 'includes/meta-box.php';
require_once plugin_dir_path(__FILE__) . 'includes/push-notification.php';
require_once plugin_dir_path(__FILE__) . 'includes/db-management.php';

// Plugin activation hook
register_activation_hook(__FILE__, 'aplu_push_activate');

// Plugin deactivation hook
register_deactivation_hook(__FILE__, 'aplu_push_deactivate');

// Add 'Settings' link to plugin on the installed plugins page
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'aplu_push_plugin_action_links');
if (!function_exists('aplu_push_plugin_action_links')) {
    function aplu_push_plugin_action_links($links) {
        $settings_link = '<a href="admin.php?page=aplu-push-settings">' . __('Settings', 'aplu-push') . '</a>';
        array_unshift($links, $settings_link);
        return $links;
    }
}

// Load text domain for translations
function aplu_push_load_textdomain() {
    load_plugin_textdomain('aplu-push', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'aplu_push_load_textdomain');

// Example of feature-specific compatibility check
global $wp_version;
if (version_compare($wp_version, '5.0', '<')) {
    // Handle pre-5.0 functionality, e.g., Classic Editor compatibility
} else {
    // Handle 5.0 and later functionality, e.g., Block Editor compatibility
}
