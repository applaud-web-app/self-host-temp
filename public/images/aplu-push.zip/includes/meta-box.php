<?php

// Add meta box to post editor only if the domain key is verified
function aplu_push_add_meta_box() {
    $key_verified = get_option('aplu_push_key_verified', false);

    if ($key_verified && current_user_can('edit_posts')) {
        add_meta_box(
            'aplu_push_meta_box',
            esc_html__('Aplu Push Notification', 'aplu-push'),
            'aplu_push_meta_box_callback',
            'post',
            'side',
            'high'
        );
    }
}
add_action('add_meta_boxes', 'aplu_push_add_meta_box');

// Meta box callback function
function aplu_push_meta_box_callback($post) {
    wp_nonce_field('aplu_push_save_meta_box_data', 'aplu_push_meta_box_nonce');

    $post_status = get_post_status($post->ID);
    $custom_title = ($post_status === 'auto-draft') ? '' : (get_post_meta($post->ID, '_aplu_push_custom_title', true) ?: get_the_title($post->ID));
    $custom_description = get_post_meta($post->ID, '_aplu_push_custom_description', true) ?: get_the_excerpt($post->ID);
    
    // Use thumbnail size for better performance
    $custom_image = get_post_meta($post->ID, '_aplu_push_custom_image', true) ?: wp_get_attachment_image_url(get_post_thumbnail_id($post->ID), 'thumbnail');

    // Always use the setting value to determine the checkbox state
    $default_checkbox_value = get_option('aplu_push_checkbox_default', 0);
    $send_notification = $default_checkbox_value ? '1' : '0';


    $aplulimit = isset($_COOKIE['aplulimit']) ? sanitize_text_field($_COOKIE['aplulimit']) : '';
    $aplu_limit_count = isset($_COOKIE['aplu_limitCount']) ? (int) $_COOKIE['aplu_limitCount'] : 0;
    $aplu_limit_date  = isset($_COOKIE['aplu_limitDate']) ? sanitize_text_field($_COOKIE['aplu_limitDate']) : '';
    // Compare the cookie date to "today"
    $today = date('Y-m-d');
    // If aplulimit is "active" AND today's date matches the cookie date,
    if ($aplulimit === 'active' && $aplu_limit_date === $today) {
        echo '<p style="color: red; font-weight: bold;">'
           . esc_html__('Today limit exceed', 'aplu-push')
           . ' (' . esc_html($aplu_limit_count) . ')</p>';
    } else {
        // Otherwise, delete the cookies by setting their expiration time in the past
        if (isset($_COOKIE['aplulimit'])) {
            setcookie('aplulimit', '', time() - 3600, '/');
        }
        if (isset($_COOKIE['aplu_limitCount'])) {
            setcookie('aplu_limitCount', '', time() - 3600, '/');
        }
        if (isset($_COOKIE['aplu_limitDate'])) {
            setcookie('aplu_limitDate', '', time() - 3600, '/');
        }
    }
    ?>
    <div id="aplu_push_notification_form">
        <input type="hidden" name="aplu_push_form_saved" value="1" />
        <p>
            <label for="aplu_push_send_notification">
                <input type="checkbox" id="aplu_push_send_notification" name="aplu_push_send_notification" value="1" <?php checked($send_notification, '1'); ?> />
                <?php esc_html_e('Send Push Notification', 'aplu-push'); ?>
            </label>
        </p>
        <p>
            <label for="aplu_push_custom_title"><?php esc_html_e('Notification Title', 'aplu-push'); ?></label>
            <input type="text" id="aplu_push_custom_title" name="aplu_push_custom_title" value="<?php echo esc_attr($custom_title); ?>" class="widefat" />
        </p>
        <p>
            <label for="aplu_push_custom_description"><?php esc_html_e('Notification Description', 'aplu-push'); ?></label>
            <textarea id="aplu_push_custom_description" name="aplu_push_custom_description" class="widefat"><?php echo esc_textarea($custom_description); ?></textarea>
        </p>
        <p>
            <label for="aplu_push_custom_image"><?php esc_html_e('Notification Image URL', 'aplu-push'); ?></label>
            <input type="text" id="aplu_push_custom_image" name="aplu_push_custom_image" value="<?php echo esc_attr($custom_image); ?>" class="widefat" />
        </p>

        <p>
            <button type="button" id="aplu_push_save_button" class="button button-primary" style="display:none;"><?php esc_html_e('Save', 'aplu-push'); ?></button>
            <button type="button" id="aplu_push_edit_button" class="button button-secondary" style="display:none;"><?php esc_html_e('Edit', 'aplu-push'); ?></button>
        </p>
    </div>

   <script type="text/javascript">
document.addEventListener('DOMContentLoaded', function() {
    let autoTypingActive = true;
    const saveButton = document.getElementById('aplu_push_save_button');
    const editButton = document.getElementById('aplu_push_edit_button');
    const formElements = document.querySelectorAll('#aplu_push_notification_form input, #aplu_push_notification_form textarea');

    const titleField = document.getElementById('aplu_push_custom_title');
    const descriptionField = document.getElementById('aplu_push_custom_description');
    const imageUrlField = document.getElementById('aplu_push_custom_image');
    const notificationCheckbox = document.getElementById('aplu_push_send_notification');

    // Function to prevent changes to the checkbox (simulating read-only)
    function makeCheckboxReadOnly() {
        notificationCheckbox.addEventListener('click', preventCheckboxChange);
        notificationCheckbox.parentElement.style.opacity = '0.5'; // Grey out the checkbox
        notificationCheckbox.style.pointerEvents = 'none'; // Disable interaction
    }

    function preventCheckboxChange(event) {
        event.preventDefault(); // Prevent checkbox state change
    }

    function removeCheckboxReadOnly() {
        notificationCheckbox.removeEventListener('click', preventCheckboxChange);
        notificationCheckbox.parentElement.style.opacity = '1'; // Restore original opacity
        notificationCheckbox.style.pointerEvents = 'auto'; // Re-enable interaction
    }

    // Ensure form is enabled and checkbox is checked on load
    function resetForm() {
        // Enable title, description, and image URL fields
        titleField.removeAttribute('readonly');
        descriptionField.removeAttribute('readonly');
        imageUrlField.removeAttribute('readonly');

        // Enable checkbox and ensure it's checked
        removeCheckboxReadOnly();  // Remove the read-only behavior
        notificationCheckbox.checked = <?php echo $send_notification === '1' ? 'true' : 'false'; ?>;
    }

    // Call the resetForm function on page load to ensure form is reset
    resetForm();

    function autoTypeForm() {
        if (!autoTypingActive) return;
        // Only run if wp.data is available (i.e. in Gutenberg)
        if (typeof wp === 'undefined' || !wp.data || !wp.data.select('core/editor')) return;

        let aplu_title_limit = 60;
        let aplu_content_limit = 150;

        const wp_editor_title = wp.data.select('core/editor').getEditedPostAttribute('title');
        const wp_editor_content = wp.data.select('core/editor').getEditedPostAttribute('content');

        if (wp_editor_title) {
            const trimmedTitle = wp_editor_title.substr(0, aplu_title_limit);
            titleField.value = trimmedTitle;
        }

        if (wp_editor_content) {
            const plainContent = wp_editor_content.replace(/(<([^>]+)>)/gi, "").substr(0, aplu_content_limit);
            descriptionField.value = plainContent.trim();
        }
    }

    // Subscribe only if wp.data is available
    if (typeof wp !== 'undefined' && wp.data && wp.data.select('core/editor')) {
        wp.data.subscribe(autoTypeForm);
    }

    formElements.forEach(function(element) {
        element.addEventListener('input', function() {
            autoTypingActive = false;
            saveButton.style.display = 'inline-block';
        });
    });

    saveButton.addEventListener('click', function() {
        const title = titleField.value.trim();
        const description = descriptionField.value.trim();
        const sendNotification = notificationCheckbox.checked ? '1' : '0';
        const nonce = document.getElementById('aplu_push_meta_box_nonce').value;

        if (sendNotification === '1' && (!title || !description)) {
            alert('Please provide both a title and description for the push notification.');
            return;
        }

        const formData = new FormData();
        const postID = '<?php echo esc_attr($post->ID); ?>'; // Escaping the post ID

        formData.append('action', 'save_aplu_push_form');
        formData.append('post_id', postID);
        formData.append('aplu_push_send_notification', sendNotification);
        formData.append('aplu_push_custom_title', title);
        formData.append('aplu_push_custom_description', description);
        formData.append('aplu_push_custom_image', imageUrlField.value.trim());
        formData.append('aplu_push_meta_box_nonce', nonce);

        fetch('<?php echo esc_url(admin_url('admin-ajax.php')); ?>', { // Escaping admin_url
            method: 'POST',
            body: formData
        }).then(response => response.json()).then(data => {
            if (data.success) {
                // Make title, description, and image URL fields read-only
                titleField.setAttribute('readonly', 'readonly');
                descriptionField.setAttribute('readonly', 'readonly');
                imageUrlField.setAttribute('readonly', 'readonly');

                // Simulate checkbox read-only (prevent changes but don't disable it)
                makeCheckboxReadOnly();

                saveButton.style.display = 'none';
                editButton.style.display = 'inline-block';
            } else {
                alert('Failed to save data: ' + data.message);
            }
        }).catch(error => {
            console.error('Error:', error);
            alert('An error occurred while saving the data.');
        });
    });

    editButton.addEventListener('click', function() {
        // Make title, description, and image URL fields editable again
        titleField.removeAttribute('readonly');
        descriptionField.removeAttribute('readonly');
        imageUrlField.removeAttribute('readonly');

        // Re-enable checkbox interaction
        removeCheckboxReadOnly();

        editButton.style.display = 'none';
        saveButton.style.display = 'inline-block';
    });

    function updateFeaturedImage() {
        // Only run if wp.data is available (i.e. in Gutenberg)
        if (typeof wp === 'undefined' || !wp.data || !wp.data.select('core/editor')) return;

        const featuredImageId = wp.data.select('core/editor').getEditedPostAttribute('featured_media');

        if (featuredImageId) {
            if (!imageUrlField.value) {
                wp.media.attachment(featuredImageId).fetch().then(function() {
                    const featuredImageUrl = wp.media.attachment(featuredImageId).get('sizes')?.large?.url || wp.media.attachment(featuredImageId).get('sizes')?.thumbnail?.url || wp.media.attachment(featuredImageId).get('url');
                    if (featuredImageUrl) {
                        imageUrlField.value = featuredImageUrl;
                    }
                });
            }
        } else {
            imageUrlField.value = ''; // Clear if no featured image
        }
    }

    // Subscribe to featured image changes only if wp.data is available
    if (typeof wp !== 'undefined' && wp.data && wp.data.select('core/editor')) {
        let previousFeaturedImageId = null;
        wp.data.subscribe(function() {
            const featuredImageId = wp.data.select('core/editor').getEditedPostAttribute('featured_media');
            if (featuredImageId !== previousFeaturedImageId) {
                updateFeaturedImage();
                previousFeaturedImageId = featuredImageId;
            }
        });

        updateFeaturedImage();
    }
});
</script>


    <?php
}

// AJAX handler to save form data
function aplu_push_ajax_save_form() {
    $post_id = intval($_POST['post_id']);

    // Check if our nonce is set and verify it
    if (!isset($_POST['aplu_push_meta_box_nonce']) || !wp_verify_nonce($_POST['aplu_push_meta_box_nonce'], 'aplu_push_save_meta_box_data')) {
        wp_send_json_error(array('message' => 'Nonce verification failed.'));
        wp_die();  // Stop further execution
    }

    // Check user permissions
    if (!current_user_can('edit_post', $post_id)) {
        wp_send_json_error(array('message' => 'Permission denied.'));
        wp_die();  // Stop further execution
    }

    // Proceed with saving data
    $send_notification = isset($_POST['aplu_push_send_notification']) ? 1 : 0;
    update_post_meta($post_id, '_aplu_push_send_notification', $send_notification);

    // Update the custom title
    if (isset($_POST['aplu_push_custom_title'])) {
        $custom_title = sanitize_text_field($_POST['aplu_push_custom_title']);
        update_post_meta($post_id, '_aplu_push_custom_title', $custom_title);
    }

    // Update the custom description
    if (isset($_POST['aplu_push_custom_description'])) {
        $custom_description = sanitize_textarea_field($_POST['aplu_push_custom_description']);
        update_post_meta($post_id, '_aplu_push_custom_description', $custom_description);
    }

    // Update the custom image URL
    if (isset($_POST['aplu_push_custom_image'])) {
        $custom_image = esc_url_raw($_POST['aplu_push_custom_image']);
        update_post_meta($post_id, '_aplu_push_custom_image', $custom_image);
    }

    // Update form saved flag
    update_post_meta($post_id, '_aplu_push_form_saved', 1);

    // Log success and send success response
    wp_send_json_success();
    error_log('Aplu Push Notification: Meta box saving... Send Notification: ' . $send_notification);
}
add_action('wp_ajax_save_aplu_push_form', 'aplu_push_ajax_save_form');

// Hook into the post save action to automatically save the form data and trigger the notification
// function aplu_push_save_form_on_post_save($post_id) {
//     // Check if this is an autosave, if so, our form should not be processed
//     if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
//           error_log('Aplu Push Notification: Skipping due to autosave.');
//         return;
//     }

//     // Check the post type to ensure we're only processing posts
//     if ('post' !== get_post_type($post_id)) {
//         return;
//     }

//     // Check if our nonce is set and verify it
//     if (!isset($_POST['aplu_push_meta_box_nonce']) || !wp_verify_nonce($_POST['aplu_push_meta_box_nonce'], 'aplu_push_save_meta_box_data')) {
//         return;
//     }

//     // Check user permissions
//     if (!current_user_can('edit_post', $post_id)) {
//         return;
//     }

//     // Determine whether the Send Notification checkbox was checked or not
//     $send_notification = isset($_POST['aplu_push_send_notification']) ? '1' : '0';

//     // Save the Send Notification meta value
//     update_post_meta($post_id, '_aplu_push_send_notification', $send_notification);

//     // Save other form fields
//     if (isset($_POST['aplu_push_custom_title'])) {
//         $custom_title = sanitize_text_field($_POST['aplu_push_custom_title']);
//         update_post_meta($post_id, '_aplu_push_custom_title', $custom_title);
//     }

//     if (isset($_POST['aplu_push_custom_description'])) {
//         $custom_description = sanitize_textarea_field($_POST['aplu_push_custom_description']);
//         update_post_meta($post_id, '_aplu_push_custom_description', $custom_description);
//     }

//     if (isset($_POST['aplu_push_custom_image'])) {
//         $custom_image = esc_url_raw($_POST['aplu_push_custom_image']);
//         update_post_meta($post_id, '_aplu_push_custom_image', $custom_image);
//     }

//     // After saving the meta data, schedule the notification if the checkbox is checked
//     if ($send_notification === '1') {
//         aplu_push_schedule_notification($post_id);
//     } else {
//         // Clear any previously scheduled notifications if the checkbox is unchecked
//         wp_clear_scheduled_hook('aplu_push_send_notification_event', array($post_id));
//     }
// }

function aplu_push_save_form_on_post_save($post_id) {
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        error_log('Aplu Push Notification: Skipping due to autosave.');
        return;
    }

    if (wp_is_post_revision($post_id)) {
        error_log("Aplu Push Notification: Skipping due to revision for Post ID $post_id.");
        return;
    }

    if ('post' !== get_post_type($post_id)) {
        return;
    }

    if (!isset($_POST['aplu_push_meta_box_nonce']) || !wp_verify_nonce($_POST['aplu_push_meta_box_nonce'], 'aplu_push_save_meta_box_data')) {
        return;
    }

    if (!current_user_can('edit_post', $post_id)) {
        return;
    }

    $send_notification = isset($_POST['aplu_push_send_notification']) ? '1' : '0';

    error_log("Aplu Push Notification: Post ID $post_id - Checkbox Value Received: " . $send_notification);

    update_post_meta($post_id, '_aplu_push_send_notification', $send_notification);

    if (isset($_POST['aplu_push_custom_title'])) {
        $custom_title = sanitize_text_field($_POST['aplu_push_custom_title']);
        update_post_meta($post_id, '_aplu_push_custom_title', $custom_title);
    }

    if (isset($_POST['aplu_push_custom_description'])) {
        $custom_description = sanitize_textarea_field($_POST['aplu_push_custom_description']);
        update_post_meta($post_id, '_aplu_push_custom_description', $custom_description);
    }

    if (isset($_POST['aplu_push_custom_image'])) {
        $custom_image = esc_url_raw($_POST['aplu_push_custom_image']);
        update_post_meta($post_id, '_aplu_push_custom_image', $custom_image);
    }

    $saved_value = get_post_meta($post_id, '_aplu_push_send_notification', true);
    error_log("Aplu Push Notification: Post ID $post_id - Saved Meta Value: " . $saved_value);

    if ($send_notification === '1') {
        error_log("Aplu Push Notification: Scheduling Notification for Post ID $post_id.");
        aplu_push_schedule_notification($post_id);
    } else {
        $timestamp = wp_next_scheduled('aplu_push_send_notification_event', array($post_id));
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'aplu_push_send_notification_event', array($post_id));
            error_log("Aplu Push Notification: Successfully unscheduled event for Post ID $post_id.");
        } else {
            error_log("Aplu Push Notification: No scheduled event found to clear for Post ID $post_id.");
        }
        delete_transient('aplu_push_sent_' . $post_id);
        error_log("Aplu Push Notification: Transient reset for Post ID $post_id.");
    }
}
add_action('save_post', 'aplu_push_save_form_on_post_save', 100);

// Hook into the set_post_thumbnail action to automatically update the notification image URL when the featured image is set or changed
function aplu_push_update_notification_image_on_thumbnail_change($post_id, $attachment_id) {
    $featured_image_url = wp_get_attachment_image_url($attachment_id, 'large');
    update_post_meta($post_id, '_aplu_push_custom_image', esc_url_raw($featured_image_url));
}
add_action('set_post_thumbnail', 'aplu_push_update_notification_image_on_thumbnail_change', 10, 2);

// Hook into the delete_post_thumbnail action to clear the notification image URL when the featured image is removed
function aplu_push_clear_notification_image_on_thumbnail_remove($post_id) {
    delete_post_meta($post_id, '_aplu_push_custom_image');
}
add_action('delete_post_thumbnail', 'aplu_push_clear_notification_image_on_thumbnail_remove');