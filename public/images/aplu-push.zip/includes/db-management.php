<?php

// Plugin activation hook
function aplu_push_activate() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'aplu_push';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        domain_name varchar(255) NOT NULL,
        license_key varchar(255) NOT NULL,
        settings longtext NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

// Plugin deactivation hook
function aplu_push_deactivate() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'aplu_push';

    // Sanitize the table name
    $table_name = esc_sql($table_name);

    // Drop the custom table safely
    $wpdb->query("DROP TABLE IF EXISTS `$table_name`");

    // Delete the license key and other options stored in wp_options
    delete_option('aplu_push_license_key');   // Delete the license key option
    delete_option('aplu_push_domain_name');   // Delete the domain name option
    delete_option('aplu_push_key_verified');  // Delete the verification status option
    delete_option('aplu_push_settings');      // Delete any other settings related to the plugin

    // Remove the aplupush-messaging-sw.js file if it exists
    $file_path = ABSPATH . 'aplupush-messaging-sw.js';
    if (file_exists($file_path)) {
        wp_delete_file($file_path);  // Replaced @unlink() with wp_delete_file()
    }
}

