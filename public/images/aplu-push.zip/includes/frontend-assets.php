<?php

// Enqueue the plugin script on the frontend
function aplu_push_enqueue_frontend_script() {
    if (!is_admin()) {
        // Register the new script
        wp_register_script('aplu_push_notify', 'https://push.aplu.io/push-notify.js', [], null, false);
        
        // Enqueue the script
        wp_enqueue_script('aplu_push_notify');
    }
}
add_action('wp_enqueue_scripts', 'aplu_push_enqueue_frontend_script');



// Remove the existing script and add a new one
function aplu_push_replace_script() {
    // Deregister the existing script if it was registered elsewhere
    wp_deregister_script('aplu_push_notify');  // Ensure you are using the correct handle

    // Register the new script
    wp_register_script('aplu_push_notify', 'https://push.aplu.io/push-notify.js', [], null, false);

    // Enqueue the new script
    wp_enqueue_script('aplu_push_notify');
}
add_action('wp_enqueue_scripts', 'aplu_push_replace_script');
