<?php

// Enqueue plugin styles and scripts only on the plugin settings page
function aplu_push_enqueue_admin_assets($hook) {
    if ($hook === 'toplevel_page_aplu-push-settings') {
        wp_enqueue_style('aplu-push-styles', plugins_url('../assets/css/aplu-push-styles.css', __FILE__));
        wp_enqueue_script('aplu-push-admin-script', plugins_url('../assets/js/aplu-push-admin.js', __FILE__), [], null, true);
    }
}
add_action('admin_enqueue_scripts', 'aplu_push_enqueue_admin_assets');
