<?php

function aplu_push_menu() {
    // Main menu with the name "Aplu Push"
    add_menu_page(
        esc_html__('Aplu Push', 'aplu-push'),
        esc_html__('Aplu Push', 'aplu-push'),
        'manage_options',
        'aplu-push-settings',
        'aplu_push_settings_page',
        plugin_dir_url(__FILE__) . '../assets/icon.png', // Path to your custom icon
        26
    );

    // First sub-menu with the name "Configuration"
    add_submenu_page(
        'aplu-push-settings',
        esc_html__('Configuration', 'aplu-push'),
        esc_html__('Configuration', 'aplu-push'),
        'manage_options',
        'aplu-push-settings', // Same slug as the main menu to show the configuration page
        'aplu_push_settings_page'
    );

    // Second sub-menu with the name "Settings"
    add_submenu_page(
        'aplu-push-settings',
        esc_html__('Settings', 'aplu-push'),
        esc_html__('Settings', 'aplu-push'),
        'manage_options',
        'aplu-push-checkbox-settings',
        'aplu_push_checkbox_settings_page'
    );
}
add_action('admin_menu', 'aplu_push_menu');

function aplu_push_checkbox_settings_page() {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aplu_push_checkbox_nonce']) && wp_verify_nonce($_POST['aplu_push_checkbox_nonce'], 'aplu_push_save_checkbox_setting')) {
        $checkbox_default = isset($_POST['checkbox_default']) ? 1 : 0;
        update_option('aplu_push_checkbox_default', $checkbox_default);

        echo '<div class="notice notice-success"><p>✔️ ' . esc_html__('Saved Successfully', 'aplu-push') . '</p></div>';
    }

    $checkbox_default = get_option('aplu_push_checkbox_default', 0);

    ?>
    <div class="wrap">
        <h1><?php esc_html_e(' Default Settings', 'aplu-push'); ?></h1>
        <form method="post" action="">
            <?php wp_nonce_field('aplu_push_save_checkbox_setting', 'aplu_push_checkbox_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e('Automatic Notifications', 'aplu-push'); ?></th>
                
                    <td>
                        <input type="checkbox" id="checkbox_default" name="checkbox_default" value="1" <?php checked(1, $checkbox_default); ?> />
                        <label for="checkbox_default"><?php esc_html_e('Automatically notify when an article is published or updated.', 'aplu-push'); ?></label>
                        
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}


function aplu_push_admin_inline_css() {
    echo '<style>
        #adminmenu .toplevel_page_aplu-push-settings .wp-menu-image img {
            opacity: 1 !important; /* Full opacity */
        }
        #adminmenu .toplevel_page_aplu-push-settings:hover .wp-menu-image img{
            opacity: 1 !important; /* Full opacity on hover */
        }
    </style>';
}
add_action('admin_head', 'aplu_push_admin_inline_css');

// Function to obfuscate the license key
function aplu_push_obfuscate_license_key($license_key) {
    $length = strlen($license_key);
    $half_length = ceil($length / 2);
    return substr($license_key, 0, $half_length) . str_repeat('*', $length - $half_length);
}

// Display plugin settings page
function aplu_push_settings_page() {
    $domain_name = get_option('aplu_push_domain_name');
    $license_key = get_option('aplu_push_license_key', ''); // Default to an empty string if the option does not exist
    $key_verified = get_option('aplu_push_key_verified', false); // Initialize to false if not set

    if (!$domain_name) {
        $home_url = wp_parse_url(home_url());
        $domain_name = isset($home_url['host']) ? $home_url['host'] : '';
    }

    // Store both the original and obfuscated license key
    $original_license_key = $license_key;
    $display_license_key = $key_verified ? aplu_push_obfuscate_license_key($license_key) : $license_key;

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['aplu_push_nonce']) && wp_verify_nonce($_POST['aplu_push_nonce'], 'aplu_push_verify_license')) {
        $license_key = sanitize_text_field($_POST['license_key']);
        $home_url = wp_parse_url(home_url());
        $domain_name = isset($home_url['host']) ? $home_url['host'] : '';

        $response = wp_remote_post('https://push.aplu.io/api/verify-license', [
            'method'    => 'POST',
            'body'      => wp_json_encode([
                // 'domain_name' => $domain_name,
                'license_key' => $license_key,
            ]),
            'headers'   => [
                'Content-Type'  => 'application/json',
            ],
        ]);

        if (is_wp_error($response)) {
            echo '<div class="notice notice-error"><p>❌ ' . esc_html__('API request failed. Please try again later.', 'aplu-push') . '</p></div>';
        } else {
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                echo '<div class="notice notice-error"><p>⚠️ ' . esc_html__('Invalid response from API. Please contact support.', 'aplu-push') . '</p></div>';
                return;
            }

            if ($data['status'] === 'success') {
                update_option('aplu_push_domain_name', $domain_name);
                update_option('aplu_push_license_key', $license_key); // Save the license key
                update_option('aplu_push_key_verified', true); // Set verification status to true
                update_option('aplu_push_settings', $data['data']);

                echo '<div class="notice notice-success"><p>✔️ ' . esc_html__('Domain Key verified successfully! Your Aplu Push configuration has been updated.', 'aplu-push') . '</p></div>';

                aplu_push_update_file($data['data']);
                $key_verified = true; // Update the variable to reflect the new status
                $display_license_key = aplu_push_obfuscate_license_key($license_key); // Obfuscate key for display after verification
            } else {
                echo '<div class="notice notice-error"><p>❌ ' . esc_html__('Invalid Domain Key. Please double-check your key and try again.', 'aplu-push') . '</p></div>';
                update_option('aplu_push_key_verified', false); // Set verification status to false
                $key_verified = false; // Update the variable accordingly

                // Reset the license key display to allow the user to retry
                $display_license_key = $license_key;
            }
        }
    }

    // Get the image URL
    $image_url = plugins_url('../assets/webpushpopup.webp', __FILE__);

    ?>
    <div class="wrap aplu-push-settings-page">
        <h1><?php esc_html_e('Configuration 📣', 'aplu-push'); ?></h1>
      

        <div class="aplu-push-grid-container">
            <!-- First Column: Domain Key Form -->
            <div class="aplu-push-grid-column">
                <div class="aplu-push-card">
                    <div class="aplu-push-card-header">
                        <?php esc_html_e('🔑 Enter Your Domain Key', 'aplu-push'); ?>
                    </div>
                    <div class="aplu-push-card-content">
                        <form method="post" action="" id="aplu-push-form">
                            <?php wp_nonce_field('aplu_push_verify_license', 'aplu_push_nonce'); ?>
                            <input type="text" id="license_key" name="license_key" value="<?php echo esc_attr($display_license_key); ?>" class="regular-text" placeholder="<?php esc_attr_e('Your Domain Key', 'aplu-push'); ?>" <?php echo $key_verified ? 'readonly' : ''; ?> />
                            <p id="description_text">
                                <?php 
                                if ($key_verified) {
                                    esc_html_e('🎉 Congratulations! Your Domain Key has been verified successfully. You can now start sending push notifications to your users.', 'aplu-push');
                                } else {
                                    esc_html_e('Enter the unique Domain Key you received when registering your account. This key links your site to Aplu Push.', 'aplu-push');
                                }
                                ?>
                            </p>
                            <div class="aplu-push-card-footer">
                                <!-- Show the Verify button only if the license key is not verified -->
                                <button type="submit" id="verify_button" class="button button-primary" <?php echo $key_verified ? 'style="display:none;"' : ''; ?>>
                                    <?php esc_html_e('Verify Key', 'aplu-push'); ?>
                                </button>
                                <!-- Show the Edit button only if the license key is verified -->
                                <button type="button" id="edit_button" class="button" <?php echo !$key_verified ? 'style="display:none;"' : ''; ?>>
                                    <?php esc_html_e('✏️ Edit Key', 'aplu-push'); ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Support Card -->
                <div class="aplu-push-card support-card">
                    <div class="aplu-push-card-header">
                        <?php esc_html_e('💬 Need Help?', 'aplu-push'); ?>
                    </div>
                    <div class="aplu-push-card-content">
                    <p><?php esc_html_e('Have questions? Our support team is here to help! Contact us using any of the methods below.', 'aplu-push'); ?></p>
                   <ul>
                        <li>
                           <svg stroke="currentColor" fill="#25D366" stroke-width="0" viewBox="0 0 448 512" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z"></path></svg>
                            <strong><?php esc_html_e('WhatsApp:', 'aplu-push'); ?></strong> 
                            <a href="https://api.whatsapp.com/send/?phone=919997526894&text=Hi%2C+I+need+help+with+Aplu+Push+Plugin.&type=phone_number&app_absent=0" target="_blank">
                                <?php esc_html_e('Send Message', 'aplu-push'); ?>
                            </a>
                        </li>
                        <li>
                          <svg stroke="currentColor" fill="#2c3e50" stroke-width="0" viewBox="0 0 320 512" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path d="M272 0H48C21.5 0 0 21.5 0 48v416c0 26.5 21.5 48 48 48h224c26.5 0 48-21.5 48-48V48c0-26.5-5.4-12-12-12H60c-6.6 0-12 5.4-12 12v312zM160 480c-17.7 0-32-14.3-32-32s14.3-32 32-32 32 14.3 32 32-14.3 32-32 32zm112-108c0 6.6-5.4 12-12 12H60c-6.6 0-12-5.4-12-12V60c0-6.6 5.4-12 12-12h200c6.6 0 12 5.4 12 12v312z"></path></svg>
                            <strong><?php esc_html_e('Phone:', 'aplu-push'); ?></strong> 
                            <a href="tel:+919997526894"><?php esc_html_e('+91 99975-26894', 'aplu-push'); ?></a>
                        </li>
                        <li>
                            <svg stroke="currentColor" fill="#2c3e50" stroke-width="0" viewBox="0 0 512 512" height="1em" width="1em" xmlns="http://www.w3.org/2000/svg"><path fill="none" stroke-miterlimit="10" stroke-width="32" d="M256 64C150 64 64 150 64 256s86 192 192 192 192-86 192-192S362 64 256 64z"></path><path fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="32" d="M256 128v144h96"></path></svg>
                            <strong><?php esc_html_e('Support Hours:', 'aplu-push'); ?></strong> 
                            <?php esc_html_e('Monday - Saturday from 9 am to 6 pm', 'aplu-push'); ?>
                        </li>
                    </ul>
                </div>
                </div>
            </div>

            <!-- Second Column: Image and Steps in a Card -->
            <div class="aplu-push-grid-column">
                <div class="aplu-push-card">
                    <div class="aplu-push-image">
                        <img src="<?php echo esc_url($image_url); ?>" alt="<?php esc_attr_e('Allow Popup Image', 'aplu-push'); ?>" style="max-width:100%;height:auto; width:350px;">
                    </div>
                    <div class="aplu-push-steps-card">
                        <div class="aplu-push-card-header">
                            <?php esc_html_e('📝 How to Set Up Aplu Push Notifications', 'aplu-push'); ?>
                        </div>
                        <div class="aplu-push-steps-card-content">
                            <ol class="aplu-push-steps-list">
                                <li>
                                    <strong><?php esc_html_e('Step 1:', 'aplu-push'); ?></strong>
                                    <?php esc_html_e('Create an account at ', 'aplu-push'); ?><a href="https://push.aplu.io" target="_blank"><?php esc_html_e('Aplu Push Platform 🌐', 'aplu-push'); ?></a>.
                                    <p class="step-description"><?php esc_html_e('If you are new, register for an account. If you already have an account, simply log in with your credentials.', 'aplu-push'); ?></p>
                                </li>
                                <li>
                                    <strong><?php esc_html_e('Step 2:', 'aplu-push'); ?></strong>
                                    <?php esc_html_e('Add your website to the dashboard by entering your site domain.', 'aplu-push'); ?>
                                    <p class="step-description"><?php esc_html_e('In the dashboard, go to the "Sites" section and add your website. This will generate a unique Domain Key for your site.', 'aplu-push'); ?></p>
                                </li>
                                <li>
                                    <strong><?php esc_html_e('Step 3:', 'aplu-push'); ?></strong>
                                    <?php esc_html_e('Copy the Domain Key from your dashboard.', 'aplu-push'); ?>
                                    <p class="step-description"><?php esc_html_e('Find your Domain Key in the "Settings" section of your site in the Aplu Push dashboard. Copy it for use in your WordPress site.', 'aplu-push'); ?></p>
                                </li>
                                <li>
                                    <strong><?php esc_html_e('Step 4:', 'aplu-push'); ?></strong>
                                    <?php esc_html_e('Return to this settings page and paste your Domain Key in the input field above.', 'aplu-push'); ?>
                                    <p class="step-description"><?php esc_html_e('Click "Verify Key" to complete the setup. You are now ready to start sending push notifications to your users! 🎉', 'aplu-push'); ?></p>
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script>
            // Store the original license key
            const originalLicenseKey = "<?php echo rawurlencode($original_license_key); ?>";
        
            // Remove success or error messages after 5 seconds
            setTimeout(function() {
                var notices = document.querySelectorAll('.notice');
                notices.forEach(function(notice) {
                    notice.style.display = 'none';
                });
            }, 5000);
        
            // Enable editing when the "Edit" button is clicked and show the original license key
            document.getElementById('edit_button').addEventListener('click', function() {
                var licenseKeyInput = document.getElementById('license_key');
                licenseKeyInput.value = decodeURIComponent(originalLicenseKey); // Decode the key to show the correct value
                licenseKeyInput.readOnly = false;
                document.getElementById('verify_button').style.display = 'inline-block';
                this.style.display = 'none';

                // Change the description text when editing
                document.getElementById('description_text').innerText = "<?php esc_html_e('Enter the unique Domain Key you received when registering your account. This key links your site to Aplu Push.', 'aplu-push'); ?>";
            });
        </script>

    </div>
    <?php
}

// Add 'Settings' link to plugin on the installed plugins page
function aplu_push_plugin_action_links($links) {
    $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=aplu-push-settings')) . '">' . esc_html__('Settings', 'aplu-push'). '</a>';
    array_push($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'aplu_push_plugin_action_links');
