<?php

// Function to create or update the aplupush-messaging-sw.js file
function aplu_push_update_file($settings) {
    // Initialize the WP_Filesystem API
    if ( ! function_exists( 'WP_Filesystem' ) ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
    }

    $creds = request_filesystem_credentials( site_url() );
    if ( ! WP_Filesystem( $creds ) ) {
        echo '<div class="notice notice-error"><p>' . esc_html__('Failed to initialize filesystem. Please check your file permissions.', 'aplu-push') . '</p></div>';
        return;
    }

    global $wp_filesystem;

    $file_path = ABSPATH . 'aplupush-messaging-sw.js';
    
    $fileContent = "importScripts('https://www.gstatic.com/firebasejs/8.3.2/firebase-app.js');
        importScripts('https://www.gstatic.com/firebasejs/8.3.2/firebase-messaging.js');

        // Initialize Firebase
        const apluPushConfig = {
            apiKey: '{$settings['apiKey']}',
            authDomain: '{$settings['authDomain']}',
            projectId: '{$settings['projectId']}',
            storageBucket: '{$settings['storageBucket']}',
            messagingSenderId: '{$settings['messagingSenderId']}',
            appId: '{$settings['appId']}'
        };

        try {
            importScripts('https://push.aplu.io/import-aplu-messaging.js');
        } catch (err) {
            console.warn('Could not load aplu-script, falling back: ', err);
        }";

    // Write the file content using WP_Filesystem API
    if ( ! $wp_filesystem->put_contents( $file_path, $fileContent, FS_CHMOD_FILE ) ) {
        echo '<div class="notice notice-error"><p>' . esc_html__('Failed to update SW file. Please check your file permissions.', 'aplu-push') . '</p></div>';
    } else {
        echo '<div class="notice notice-success"><p>' . esc_html__('File has been created successfully.', 'aplu-push') . '</p></div>';
    }
}
