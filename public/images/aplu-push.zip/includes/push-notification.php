<?php
/**
 * Plugin Name: Aplu Push Notification
 * Description: Sends push notifications in background and manages cookies for 'limit' and 'limitCount'.
 * Version: 1.0.2
 */
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
/**
 * 1. Schedules the push notification upon saving a post.
 */
add_action('save_post', 'aplu_push_schedule_notification');
function aplu_push_schedule_notification($post_id) {
    // Avoid autosaves or revisions
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        error_log('Aplu Push Notification: Skipping due to autosave.');
        return;
    }
    if (wp_is_post_revision($post_id)) {
        error_log('Aplu Push Notification: Skipping due to revision.');
        return;
    }
    // Prevent multiple schedules in the same request
    static $already_scheduled = false;
    if ($already_scheduled) {
        return;
    }
    $already_scheduled = true;
    // Ensure the post is published
    $post = get_post($post_id);
    if (!$post) {
        error_log('Aplu Push Notification: Post not found.');
        return;
    }
    if ($post->post_status !== 'publish') {
        error_log('Aplu Push Notification: Post not published.');
        return;
    }
    // Check if the custom field says "send notification"
    $send_notification = get_post_meta($post_id, '_aplu_push_send_notification', true);
    if ($send_notification !== '1') {
        error_log('Aplu Push Notification: Send notification not enabled.');
        return;
    }
    error_log('Aplu Push Notification: Send notification enabled, scheduling...');
    // Schedule the event if not already scheduled
    if (!wp_next_scheduled('aplu_push_send_notification_event', array($post_id))) {
        wp_schedule_single_event(time() + 3, 'aplu_push_send_notification_event', array($post_id));
    } else {
        error_log('Aplu Push Notification: Notification already scheduled.');
    }
}
/**
 * 2. WP-Cron callback to send the notification.
 */
add_action('aplu_push_send_notification_event', 'aplu_push_send_notification');
function aplu_push_send_notification($post_id) {
    
    error_log("Aplu Push Notification: Sending notification for Post ID $post_id...");

    // Verify if the meta field says to send notification
    $send_notification = get_post_meta($post_id, '_aplu_push_send_notification', true);
    error_log("Aplu Push Notification: Meta value retrieved = $send_notification");

    if ($send_notification !== '1') {
        error_log("Aplu Push Notification: Skipping because send_notification is not 1.");
        return;
    }
    
    // Use a transient to prevent duplicate sends in a short time
    $transient_key = 'aplu_push_sent_' . $post_id;
    if (false !== get_transient($transient_key)) {
        error_log('Aplu Push Notification: Notification already sent recently.');
        return;
    }
    // Gather the data
    $title       = get_post_meta($post_id, '_aplu_push_custom_title', true)       ?: get_the_title($post_id);
    $description = get_post_meta($post_id, '_aplu_push_custom_description', true) ?: get_the_excerpt($post_id);
    $target_url  = get_post_meta($post_id, '_aplu_push_custom_target_url', true)  ?: get_permalink($post_id);
    $image       = get_post_meta($post_id, '_aplu_push_custom_image', true)       ?: get_the_post_thumbnail_url($post_id);
    // Ensure required fields are not empty
    if (empty($title) || empty($description) || empty($target_url)) {
        error_log('Aplu Push Notification: Missing required fields. Notification not sent.');
        return;
    }
    // License key
    $license_key = get_option('aplu_push_license_key');
    if (empty($license_key)) {
        error_log('Aplu Push Notification: License key is missing.');
        return;
    }
    // Build the request body
    $data = [
        'title'       => sanitize_text_field($title),
        'description' => sanitize_text_field($description),
        'target_url'  => esc_url_raw($target_url),
        'bannerimage' => esc_url_raw($image),
        'domain_name' => sanitize_text_field(wp_parse_url(home_url(), PHP_URL_HOST)),
        'license_key' => sanitize_text_field($license_key),
    ];
    error_log('Aplu Push Notification Data: ' . print_r($data, true));
    // Make the request
    $response = wp_remote_post('https://push.aplu.io/api/send-push-notification', [
        'method'  => 'POST',
        'body'    => wp_json_encode($data),
        'headers' => [
            'Content-Type' => 'application/json',
        ],
    ]);
    if (is_wp_error($response)) {
        // Retry if needed
        $error_message = $response->get_error_message();
        error_log("Aplu Push Notification Error: $error_message");
        $retry_count = get_post_meta($post_id, '_aplu_push_retry_count', true) ?: 0;
        if ($retry_count < 3) {
            $retry_delay = 60; // 1 minute
            update_post_meta($post_id, '_aplu_push_retry_count', $retry_count + 1);
            wp_schedule_single_event(time() + $retry_delay, 'aplu_push_send_notification_event', array($post_id));
        } else {
            error_log("Aplu Push Notification: Retry limit reached. No further retries.");
        }
    } else {
        // Handle success/error response
        $body        = wp_remote_retrieve_body($response);
        $status_code = wp_remote_retrieve_response_code($response);
        error_log("Aplu Push Notification Response Code: $status_code");
        error_log("Aplu Push Notification Response Body: $body");
        $response_data = json_decode($body, true);
        // Check the 'limit' and 'limitCount' fields
        if (is_array($response_data)) {
            // 1) Handle the 'limit' field
            if (array_key_exists('limit', $response_data)) {
                if ($response_data['limit'] === false) {
                    update_option('aplu_limit_state', 'false');
                    error_log("Aplu Push Notification: limit=false stored in option.");
                } elseif ($response_data['limit'] === true) {
                    update_option('aplu_limit_state', 'true');
                    error_log("Aplu Push Notification: limit=true stored in option.");
                }
            }
            // 2) Handle the 'limitCount' field
            if (array_key_exists('limitCount', $response_data)) {
                $count = (int) $response_data['limitCount'];
                update_option('aplu_limit_count', $count);
                error_log("Aplu Push Notification: limitCount=$count stored in option.");
            }
        }
        // If response code is 2xx, mark as sent
        if ($status_code >= 200 && $status_code < 300) {
            set_transient($transient_key, 'sent', 600);
            error_log("Aplu Push Notification: Successfully sent notification.");
        } else {
            error_log("Aplu Push Notification: Failed with status code $status_code.");
        }
    }
}
add_action('init', 'aplu_maybe_set_or_unset_cookies', 1);
function aplu_maybe_set_or_unset_cookies() {
    // Only run on front-end (not in admin, not for REST API)
    if (is_admin() || (defined('REST_REQUEST') && REST_REQUEST)) {
        return;
    }
    // Avoid "headers already sent" warning
    if (headers_sent()) {
        return;
    }
    // Check stored state from API response
    $limit_state = get_option('aplu_limit_state', '');
    $limit_count = get_option('aplu_limit_count', 0); // integer
    // Only update cookies if limit state is 'false' (limit reached)
    if ($limit_state === 'false') {
        // 1) Set 'aplulimit' to 'active'
        if (!isset($_COOKIE['aplulimit']) || $_COOKIE['aplulimit'] !== 'active') {
            setcookie('aplulimit', 'active', time() + 86400, '/'); // 1 day
        }
        // 2) Set 'aplu_limitCount' to the numeric value
        $current_count_cookie = isset($_COOKIE['aplu_limitCount']) ? (int) $_COOKIE['aplu_limitCount'] : 0;
        if ($current_count_cookie !== $limit_count) {
            setcookie('aplu_limitCount', $limit_count, time() + 86400, '/');
        }
        // 3) Set 'aplu_limitDate' to today's date (YYYY-MM-DD)
        $today_date = date('Y-m-d');
        $current_date_cookie = isset($_COOKIE['aplu_limitDate']) ? sanitize_text_field($_COOKIE['aplu_limitDate']) : '';
        if ($current_date_cookie !== $today_date) {
            setcookie('aplu_limitDate', $today_date, time() + 86400, '/');
        }
    } else {
         // Delete 'aplulimit'
        if (isset($_COOKIE['aplulimit'])) {
            setcookie('aplulimit', '', time() - 3600, '/');
        }
    
        // Delete 'aplu_limitCount'
        if (isset($_COOKIE['aplu_limitCount'])) {
            setcookie('aplu_limitCount', '', time() - 3600, '/');
        }
    
        // Delete 'aplu_limitDate'
        if (isset($_COOKIE['aplu_limitDate'])) {
            setcookie('aplu_limitDate', '', time() - 3600, '/');
        }
        // When limit_state is 'true', do nothing.
        error_log("Aplu Push Notification: 'limit' is true. No cookie actions performed.");
    }
}










