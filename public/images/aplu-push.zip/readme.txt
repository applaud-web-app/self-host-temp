=== Aplu Push ===
Contributors: Aplu
Tags: notifications, push notifications, web push, user engagement, alerts
Requires at least: 6.0
Tested up to: 6.6.1
Stable tag: 1.0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Aplu Push allows you to easily set up push notifications for your WordPress website, notifying your users of new content, updates, and more.

== Description ==

**Aplu Push** is a powerful WordPress plugin developed by **Applaud Web Media Pvt. Ltd.** that seamlessly integrates with the Aplu Push platform to send real-time web push notifications to your subscribers. Whether you publish new posts, pages, products, or any custom post type, Aplu Push ensures that your users are instantly notified, helping you keep them engaged and driving more return traffic to your site.

### Key Features:
- **Effortless Setup:** Quickly configure push notifications on your WordPress site without any coding.
- **Real-Time Notifications:** Automatically send notifications to your subscribers as soon as new content is published.
- **Customizable Notifications:** Tailor your notification messages, including titles and content, to align with your brand voice.
- **Subscriber Management:** View and manage your subscribers directly from your WordPress dashboard.
- **Flexible Targeting:** Send notifications for specific content types, such as blog posts, products, or news articles.
- **Seamless API Integration:** Leverages the Aplu Push API to ensure efficient delivery of notifications.
- **Device and Browser Compatibility:** Works across all major browsers and devices, including mobile and desktop.
- **Multi-Language Support:** Fully translatable, allowing you to send notifications in multiple languages based on your site’s locale.
- **Classic Editor Compatibility:** Supports the WordPress Classic Editor for a seamless experience when creating content.

### Benefits:
- **Boost Engagement:** Keep your audience engaged by notifying them of new content, offers, or updates instantly.
- **Increase Traffic:** Drive more return traffic to your site by reaching users directly on their devices, even when they aren’t actively browsing your site.
- **Simple Integration:** Set up push notifications in just a few steps, making it accessible for both beginners and experienced developers.

### Use Cases:
- **Bloggers:** Notify your readers instantly when you publish a new post to keep them coming back.
- **E-commerce:** Send notifications about new products, sales, or discounts to drive more purchases.
- **News Portals:** Ensure your readers are informed immediately when breaking news is published.
- **Event Organizers:** Promote upcoming events or webinars to registered users with timely notifications.

== Installation ==

### Automatic Installation:
1. In your WordPress dashboard, go to **Plugins > Add New**.
2. Search for **Aplu Push** in the plugin repository.
3. Click **Install Now** and then **Activate**.
4. After activation, navigate to **Aplu Push > Settings** to configure the plugin.

### Manual Installation:
1. Download the plugin zip file from the WordPress plugin repository or from your account.
2. In your WordPress dashboard, go to **Plugins > Add New**.
3. Click **Upload Plugin**, then choose the downloaded zip file and click **Install Now**.
4. After installation, click **Activate**.
5. Go to **Aplu Push 🔔 > Settings** to complete the setup.

### Initial Setup:
1. **Create an Aplu Push Account:** Visit the [Aplu Push website](https://push.aplu.io) and create an account if you haven't done so already.
2. **Add Your Website:** Log in to your Aplu Push dashboard and add your website’s domain.
3. **Obtain Your Domain Key:** Once your website is added, navigate to the "Settings" section in your Aplu Push dashboard to find your Domain Key.
4. **Configure Plugin Settings:** Paste your Domain Key into the plugin settings page in WordPress and click **Verify Key**.
5. **Start Sending Notifications:** Once verified, Aplu Push will automatically send notifications whenever new content is published.

== Frequently Asked Questions ==

= How do I obtain my Domain Key? =
To get your Domain Key, log in to your [Aplu Push account](https://push.aplu.io) and add your website to the dashboard. Once added, you can find your Domain Key in the "Settings" section. This key is required to link your website to the Aplu Push platform.

= What happens after I verify my Domain Key? =
After successful verification, your WordPress site will be linked to the Aplu Push platform. The plugin will automatically send push notifications to your subscribers whenever new content is published. You can also manage notification settings and customize messages from the plugin's settings page.

= Can I customize the content of my notifications? =
Yes, after your Domain Key is verified, you can navigate to the plugin settings page to customize the title and content of your push notifications. You can also disable automatic notifications for specific content types or set up custom messages for different post categories.

= Can I see a list of my subscribers? =
Yes, Aplu Push provides a subscriber management section within the WordPress dashboard. You can view your subscriber list, see detailed information such as browser and device types, and manage subscribers by removing or exporting their data.

= What if my Domain Key verification fails? =
If verification fails, double-check that you have entered the correct Domain Key and that your website is correctly configured in the Aplu Push dashboard. If you continue to experience issues, please contact [Aplu Push Support](https://push.aplu.io/support) for assistance.

= Is Aplu Push compatible with all browsers? =
Yes, Aplu Push is compatible with all major browsers, including Chrome, Firefox, Safari, and Edge. It also works on both desktop and mobile devices.

= Is Aplu Push compatible with the Classic Editor? =
Yes, Aplu Push is fully compatible with the WordPress Classic Editor, allowing you to seamlessly integrate push notifications without changing your editing workflow.

== Screenshots ==

1. **Settings Page:** Configure the Domain Key, customize notifications, and manage settings.
2. **Push Notification Example:** A sample push notification as it appears on a user’s device.
3. **Subscriber Management:** View and manage your subscribers directly from your WordPress admin panel.
4. **Notification Log:** See a log of all notifications that have been sent through your site.

== Changelog ==

= 1.0.1 =  
* Minor bug fixes and performance improvements.  
* Updated documentation links.  
* Added compatibility with the WordPress Classic Editor.

= 1.0.0 =  
* Initial release of Aplu Push.  
* Added integration with the Aplu Push API for seamless notification delivery.  
* Implemented automatic and customizable notifications.  
* Added subscriber management features within the WordPress dashboard.  
* Multi-language support.

== Upgrade Notice ==

= 1.0.1 =  
This update includes compatibility with the WordPress Classic Editor, minor bug fixes, and performance improvements. Please ensure your Domain Key is still verified after upgrading.

= 1.0.0 =  
Initial release of Aplu Push. After upgrading, make sure to verify your Domain Key in the settings page to start sending notifications.

== License ==
This plugin is licensed under the GPLv2 or later.  
[http://www.gnu.org/licenses/gpl-2.0.html](http://www.gnu.org/licenses/gpl-2.0.html)

== Support ==

For support, please visit the [plugin support forum](https://wordpress.org/support/plugin/aplu-push/) or contact [Aplu Push](https://aplu.io/contact/) for assistance. Detailed documentation is also available on our [documentation page](https://push.aplu.io/docs).
