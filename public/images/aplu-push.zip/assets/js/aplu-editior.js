jQuery(document).ready(function($) {
    // Select the elements
    const postTitleField = $('#title');
    const postContentField = $('#content');
    const metaBoxTitleField = $('#aplu_push_custom_title');
    const metaBoxDescriptionField = $('#aplu_push_custom_description');
    const metaBoxTargetUrlField = $('#aplu_push_custom_target_url');
    const metaBoxImageField = $('#aplu_push_custom_image');
    
    // Function to update meta box fields
    function updateMetaBoxFields() {
        const title = postTitleField.val();
        const content = postContentField.val();
        
        metaBoxTitleField.val(title);
        
        // Remove HTML tags from content and limit the length
        const plainTextContent = $('<div>').html(content).text();
        metaBoxDescriptionField.val(plainTextContent.substr(0, 150)); // Limit to 150 characters
    }

    // Monitor changes to the post title and content
    postTitleField.on('input', updateMetaBoxFields);
    postContentField.on('input', updateMetaBoxFields);
    
    // Handle Save button click
    $('#aplu_push_save_button').on('click', function() {
        const formData = {
            action: 'save_aplu_push_form',
            security: apluAjax.nonce,
            post_id: $('#post_ID').val(),
            aplu_push_send_notification: $('#aplu_push_send_notification').is(':checked') ? 1 : 0,
            aplu_push_custom_title: metaBoxTitleField.val(),
            aplu_push_custom_description: metaBoxDescriptionField.val(),
            aplu_push_custom_target_url: metaBoxTargetUrlField.val(),
            aplu_push_custom_image: metaBoxImageField.val()
        };

        $.post(apluAjax.ajaxurl, formData, function(response) {
            if (response.success) {
                $('#aplu_push_notification_form input, #aplu_push_notification_form textarea').prop('disabled', true);
                $('#aplu_push_save_button').hide();
                $('#aplu_push_edit_button').show();
            } else {
                alert('Failed to save data');
            }
        });
    });

    // Handle Edit button click
    $('#aplu_push_edit_button').on('click', function() {
        $('#aplu_push_notification_form input, #aplu_push_notification_form textarea').prop('disabled', false);
        $(this).hide();
        $('#aplu_push_save_button').show();
    });

    // Initialize meta box fields on page load
    updateMetaBoxFields();
});
